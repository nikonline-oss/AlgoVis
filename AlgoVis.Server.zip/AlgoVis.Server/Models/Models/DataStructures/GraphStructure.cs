﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlgoVis.Models.Models.Suport;
using AlgoVis.Models.Models.DataStructures.Interfaces;
using AlgoVis.Models.Models.Visualization;

namespace AlgoVis.Models.Models.DataStructures
{
    public class GraphStructure : IDataStructure<GraphState>
    {
        public string Type => "graph";
        public string Id { get; } = Guid.NewGuid().ToString();
        public List<GraphNode> Nodes { get; set; } = new();
        public List<GraphEdge> Edges { get; set; } = new();

        public GraphState GetState() => new GraphState
        {
            Nodes = Nodes.Select(n => new GraphNode
            {
                Id = n.Id,
                Value = n.Value,
                X = n.X,
                Y = n.Y
            }).ToList(),
            Edges = Edges.Select(e => new GraphEdge
            {
                from = e.from,
                to = e.to,
                weight = e.weight
            }).ToList()
        };

        public void ApplyState(GraphState state)
        {
            Nodes = state.Nodes;
            Edges = state.Edges;
        }

        public VisualizationData ToVisualizationData()
        {
            var data = new VisualizationData { structureType = "graph" };

            foreach (var node in Nodes)
            {
                data.elements[node.Id] = new
                {
                    value = node.Value,
                    label = $"Node: {node.Value}",
                    x = node.X,
                    y = node.Y
                };
            }

            foreach (var edge in Edges)
            {
                data.connections.Add(new Connection
                {
                    FromId = edge.from,
                    ToId = edge.to,
                    Type = "edge",
                    Weight = edge.weight
                });
            }

            return data;
        }

        public GraphState GetOriginState()
        {
            throw new NotImplementedException();
        }
    }
}
